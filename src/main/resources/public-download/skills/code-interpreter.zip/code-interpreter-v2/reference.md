# Code Interpreter — Python 路径模板参考

主文件 `SKILL.md` 里只放静态路径模板（因为那是判错就崩的差异点）；Python 路径的 5 个常见任务模板放在这里，按需 Read。

> **使用方式**：模板是**起点**，**不要**死搬。写脚本时按用户实际数据改字段名 / 文件名 / 列名 / 路径；保留约定（`output/` 目录、`encoding="utf-8"`、`matplotlib.use("Agg")` 等）。

---

## 1. CSV 数据分析（带绘图）

适用：解析 / 统计 / 清洗 / 分组聚合，并出图 + 结构化产物。

```python
import os
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

os.makedirs("output", exist_ok=True)

df = pd.read_csv("input.csv", encoding="utf-8")
summary = df.groupby("category")["amount"].agg(["count", "sum", "mean"])

print(summary.to_string())

fig, ax = plt.subplots(figsize=(7, 4), dpi=120)
summary["sum"].plot(kind="bar", ax=ax)
ax.set_title("Sum by category")
fig.tight_layout()
fig.savefig("output/sum_by_category.png", bbox_inches="tight")
plt.close(fig)

summary.to_csv("output/summary.csv", encoding="utf-8-sig")
```

跑完：

1. `ExportArtifact` → `output/sum_by_category.png`（`image/png`）
2. `ExportArtifact` → `output/summary.csv`（`text/csv`）
3. 最终回复：代码块 + stdout 文本 + 图片 + csv 链接，共 4 段。

---

## 2. 纯计算 / 算法验证

适用：数学题、排序、模拟、随机抽样 —— 只要 stdout，不出文件。

```python
def fib(n: int) -> int:
    a, b = 0, 1
    for _ in range(n):
        a, b = b, a + b
    return a

for n in [10, 20, 30]:
    print(f"fib({n}) = {fib(n)}")
```

最终回复：代码块 + 情形 1 的 stdout 文本块。**不需要** `ExportArtifact`。

---

## 3. 文件批量重命名 / 转换

适用：图片整理、文件名规范化、格式转换、目录合并。

```python
from pathlib import Path

src = Path("photos")
out = Path("output/renamed")
out.mkdir(parents=True, exist_ok=True)

count = 0
for i, p in enumerate(sorted(src.glob("*.jpg")), 1):
    new_name = out / f"trip_{i:03d}.jpg"
    new_name.write_bytes(p.read_bytes())
    count += 1

print(f"renamed {count} files -> {out}")
```

产物多时打包成 zip 再导出，避免逐个 ExportArtifact 链接刷屏：

```python
import shutil
shutil.make_archive("output/renamed", "zip", "output/renamed")
```

跑完 `ExportArtifact` → `output/renamed.zip`（`application/zip`）。

---

## 4. 公开 URL 抓取 + 解析

适用：拉取页面、解析 HTML、提取字段 —— **只接受公开 URL**。

```python
import requests
from bs4 import BeautifulSoup

url = "https://example.com/article"
resp = requests.get(url, timeout=15, headers={"User-Agent": "Mozilla/5.0"})
resp.raise_for_status()

soup = BeautifulSoup(resp.text, "lxml")
title = soup.find("h1").get_text(strip=True)
paras = [p.get_text(strip=True) for p in soup.select("article p")][:3]

print(f"# {title}")
for p in paras:
    print(p)
```

**约束**：

- 失败别自动重试 —— 网络抖动让用户决定要不要重跑（避免无谓击穿对方限流）
- 不要绕过 `robots.txt`、不要请求内网地址
- 需要登录态的页面 → 直接拒绝，让用户走对应业务 skill
- **不要**改用 `WebSearch` / `SmartWebFetch`：那两个返回摘要文本，没法续传给后续脚本

---

## 5. JSON 转换 / 抽字段

适用：嵌套 JSON 压平、字段抽取、批量转换。

```python
import json

with open("data.json", "r", encoding="utf-8") as f:
    data = json.load(f)

flat = [
    {"id": item["id"], "name": item["user"]["name"], "score": item["stats"]["score"]}
    for item in data["records"]
]

print(json.dumps(flat[:5], ensure_ascii=False, indent=2))

with open("output/flat.json", "w", encoding="utf-8") as f:
    json.dump(flat, f, ensure_ascii=False, indent=2)
```

跑完 `ExportArtifact` → `output/flat.json`（`application/json`）。

---

## 通用提示

- 路径**全部**用相对路径（`output/...`），不要写 `/tmp/...` 或 `C:\...`
- 写文件前先 `os.makedirs("output", exist_ok=True)`
- 文件 I/O **显式** `encoding="utf-8"`，不要依赖系统默认
- 输出中文 JSON：`json.dumps(..., ensure_ascii=False)`
- 含中文的图：按 `SKILL.md` "图片产物" 节嵌 CJK 字体片段
