---
name: code-interpreter
description: 在沙箱里用代码解决"跑一次拿结果"或"产出一份文件"的任务，并把 stdout / 图片 / 文件规范交付。两类产物都覆盖 ——（A）需要计算才有结果：数据分析、文件处理、爬取、算法验证、绘图、格式转换、文本/正则、临时脚本验证（走 Python 路径）；（B）产物本身就是一份静态文件：HTML / CSS / JS / 单文件小游戏 / SVG / Markdown / 静态报告页（走静态路径，直接 Write 文件，不要包 Python 写盘）。当用户说"跑一下这段代码 / 帮我写段 Python / 算一下 / 处理这个 csv / 解析这个 json / 转码 / 统计 / 排序 / 抓一下 / 帮我画图 / 写个 HTML / 做个小游戏 / 给我一个静态页面 / run this code / execute python / 用代码实现 ..." 等意图时触发。所有文件产物（图片、csv、xlsx、zip、json、html、txt 等）一律通过 ExportArtifact 出下载链接。
compatibility: 沙箱内置 Python 3 + 标准库 + numpy / pandas / matplotlib / requests / pillow / openpyxl / lxml / beautifulsoup4；可执行任意 Python 脚本，但禁止依赖外部网络密钥或登录态（如需登录请走专门的登录 skill）。
---

# Code Interpreter Skill

通用代码交付器。和 ChatGPT Code Interpreter 类似，但**覆盖两类产物**：

- **要算才有结果** → 在沙箱里写 Python 脚本、跑、把 stdout / 图片 / 文件规范交付（**Python 路径**）
- **产物就是一份静态文件**（HTML / CSS / JS / SVG / Markdown） → 直接用 `Write` 把文件落盘 + `ExportArtifact` 出链接，**不要**包一层 Python `open().write()` 当 echo 用（**静态路径**）

判断走哪条路径见下面 Step 0；选错会让用户拿到一份没法直接用、还可能被截断的"伪产物"。

## 触发条件

本 skill 处理两类任务，**分别走不同路径**（Step 0 再做细分）：

**A. 需要算才有结果（Python 路径）**

- 数据处理：解析/统计/清洗 csv / json / xml / xlsx；分组聚合；去重；连接表
- 文件处理：批量重命名、格式转换、压缩、合并、抽取
- 计算/算法：数学题、统计题、排序、查找、模拟、随机抽样、回归
- 文本处理：正则匹配、编码转换、敏感词替换、关键词抽取
- 网络抓取（**仅限公开 URL**）：拉取页面、解析 HTML、提取字段
- 数据可视化：柱状图 / 折线图 / 散点图 / 热力图（绘图细节见"图片产物"）
- 临时脚本验证："这段代码会输出啥"、"复现一下这个 bug"

**B. 产物本身就是一份静态文件（静态路径）**

- 单文件 HTML 小游戏 / 演示页 / 落地页 / 静态报告
- 纯 CSS / JS / SVG / Markdown 文档片段
- 任何"代码就是交付物，不需要在沙箱里跑一次才有结果"的场景

**不在范围**：

- 需要登录 / 鉴权的接口调用 → 走对应业务 skill
- 单纯问"这段代码什么意思" → 直接解释，**不要**为了解释跑一遍

---

## 可用工具与路由

本 skill 运行在沙箱里。模型能看到的工具有十几个，**只能按下表挑**，挑错了交付就崩。

| 场景 | 用这个工具 | 不要用 |
|---|---|---|
| 写脚本 / 写静态产物（HTML / CSS / JS / SVG / Markdown） | `Write` | `Bash` + `cat <<EOF` / `echo >` |
| 跑 python / 装包 / `ls` / 临时命令 | `Bash` | （沙箱里没别的执行器，唯一选择） |
| 改 `main.py` 里一两行 | `Edit` | 整文件重写 `Write`（diff 过散） |
| 读沙箱里现有文件（用户上传 / 中间产物 / 复核脚本） | `Read` | `Bash cat / head / tail` |
| 文件产物（图片 / csv / xlsx / zip / html …）→ 下载链接 | `ExportArtifact` | base64 / data URI / 把文件内容塞进 stdout |

**本 skill 内禁用的工具**（每条都说明原因，避免误用）：

- `FinalAnswer`：returnDirect 协议，一次性把字符串吐给用户结束本轮。本 skill 的交付是"块 A 代码 + 块 B 结果"的 markdown 回复，不是裸 stdout，**走 FinalAnswer 会把代码块吃掉只剩文本**。
- `Skills`：用来加载别的 skill 的 SKILL.md。当前已经在 code-interpreter 内，绘图直接用 matplotlib、pdf 直接用 reportlab/pypdf，**不要嵌套触发别的 skill**。
- `WebSearch` / `SmartWebFetch`：本 skill 要的是"抓 → 解析 → 续跑"的代码 pipeline；那两个返回的是摘要文本，没法续传给后续脚本。所有抓取走 `requests` + `bs4` 在 Python 里完成。

---

## 执行流程总览

### Step 0：判断产物类型 → 决定路径

| 用户意图 | 走 | 原因 |
|---|---|---|
| 需要算出结果 / 处理数据 / 抓取 / 绘图 / 算法验证 / 文件转换 | **Python 路径** | 产物只能由代码跑出来 |
| 产物本身就是一份静态文件（HTML / CSS / JS / SVG / Markdown） | **静态路径** | 产物即"代码"本身，不需要在沙箱里"跑"才能产生 |

**判错的代价很大**：把静态产物走成 Python 路径，会被迫把 HTML 嵌进 `r"""..."""` 再 `open().write()`，**等于把 Python 当 echo 用**，且引号/反斜杠边界容易翻车、同一份内容写两遍 token 还会让长产物被截断。详见"硬性禁止"。

### Python 路径（4 步）

```
- [ ] 1. 拆解任务 → 决定代码框架
- [ ] 2. 用 Write 落盘 main.py（或多文件）
- [ ] 3. 用 Bash 执行 python main.py，拿到 stdout / stderr / 产物
- [ ] 4. 按"最终回复格式"规范交付
```

### 静态路径（3 步）

```
- [ ] 1. 用 Write 把目标文件原生落到 output/<name>.<ext>（不要包 main.py）
- [ ] 2. 用 ExportArtifact 出下载链接（mimeType 按"文件产物"速查表）
- [ ] 3. 按"最终回复格式"交付：块 A 用产物语言标签（html / css / svg / ...），不是 python
```

### 失败重试规则（两条路径通用）

- 同一份产物**最多重试 2 次**（共执行 3 次）。第 2 次失败仍未通过，**停手**，把最后一次的 stderr 原文报给用户决策，**不要**继续乱改。
- 改代码前先看 stderr 定位行号 / 异常类型；不要 "shotgun debug"（凭感觉改一堆地方）。
- 静态路径里如果第 2 次 stderr 与第 1 次**完全相同**，立刻停手 —— 多半是模型没读懂错误，而不是产物本身的问题。

---

## 最终回复格式（**强制统一**）

任何情况下，回给用户的正文都由两类块构成，按顺序拼接：

### 块 A —— 代码块

把**实际落盘的那一份**完整内容贴进代码块。**语言标签按路径决定**：

- Python 路径：` ```python ` + 完整 main.py
- 静态路径：` ```html ` / ` ```css ` / ` ```js ` / ` ```svg ` / ` ```markdown ` + 完整产物文件

````
```<lang>
《一字不改的产物全文》
```
````

共同硬约束：用户复制块 A 出去能直接拿到同一个产物 —— Python 路径 `python main.py` 能重跑出同一结果，静态路径 HTML 直接浏览器打开就能用。

### 块 B —— 结果块（按以下情形择一或叠加）

**情形 1：纯文本输出**（脚本只 `print`，没有产物文件）

```text
《stdout 原文；超过 60 行时截断中间，前 30 / 后 20 + 一行 "... (truncated N lines) ..."》
```

**情形 2：图片产物**

```
![chart](《http://.../download/<id>/xxx.png》)
```

**情形 3：其它文件产物**（csv、xlsx、zip、json、html、txt 等）

```
[文件名.ext](http://.../download/<id>/文件名.ext) — 简短一句话说明（可选，≤ 20 字）
```

**情形 4：错误**（重试 2 次仍失败）

```text
执行失败（已重试 2 次）：
<最后一次的 stderr 原文，截断到 ≤ 40 行>
```

### 多产物 / 混合输出

多张图、多个文件、stdout + 图 + 文件并存的情况：**块 A 只出现一次**（一份代码），**块 B 按"先文本 → 后图片 → 后文件"的顺序依次列出**。

### 硬性禁止

- ❌ 代码事后润色 / 删减 / 改名 / 改注释 —— 用户必须能复制代码再跑出**同一份**结果
- ❌ 图片在前、代码在后 —— 顺序固定：代码先，结果后
- ❌ 输出"我做了什么 / 思路是这样 / 希望对你有帮助"等寒暄；如果用户后续追问再单独解释
- ❌ 没跑成功就硬凑一个看起来像结果的 stdout —— 失败就走情形 4
- ❌ 多份脚本合并成一块再贴一堆结果 —— 一个任务一份代码块
- ❌ **把 HTML / CSS / JS / Markdown 等静态产物嵌进 `r"""..."""` 当 Python 字符串再 `open().write()` 写盘** —— 这是把 Python 当 echo 用，等于把同一份内容写两遍，且引号 / 反斜杠边界容易翻车、token 上限下半截被截断的概率显著上升。静态产物**永远走静态路径**，用 Write 直接落盘

---

## 写脚本的硬性约定

### 基本骨架

```python
# main.py
import sys, json
# 其余 import 按需

def main() -> int:
    # 业务逻辑
    ...
    return 0

if __name__ == "__main__":
    sys.exit(main())
```

### 通用规则

- **stdout 是给用户看的**：只 `print` 用户需要的结果。调试日志走 `print(..., file=sys.stderr)`。
- **stderr 用来排错**：异常不要静默吞，让 traceback 自然冒出来。
- **路径用相对路径**（如 `output/result.csv`），不要写 `/tmp/...` 或 `C:\...`，否则 ExportArtifact 拿不到。
- **写文件前先 `os.makedirs("output", exist_ok=True)`**，避免目录不存在报错。
- **不要 input()**：脚本必须非交互；用户参数在你写代码时就硬编码进去，或通过 `argparse` + Bash 调用时传。
- **不要 sleep 长时间**：超过 30s 的脚本要拆分或问用户。
- **装包走镜像**：沙箱里 pip 默认源很慢甚至超时。需要装依赖时一律带镜像，例 `pip3 install -i https://pypi.tuna.tsinghua.edu.cn/simple <pkg>`（阿里源 `https://mirrors.aliyun.com/pypi/simple` 备选）；尽量不要用裸 `pip3 install`。装包命令放 `Bash` 里执行，不要写进 `main.py`。

### 编码安全

- 处理用户给的字符串：原样保留 Unicode；`json.dumps(..., ensure_ascii=False)` 才输出中文。
- 文件 I/O 全部显式 `encoding="utf-8"`，**不要**依赖系统默认编码。

---

## 写静态产物的硬性约定

走静态路径时（HTML / CSS / JS / SVG / Markdown 等"代码即交付物"的场景）：

- **直接 Write 落盘**到 `output/<name>.<ext>`，**不要**新建 `main.py` 包一层 —— 见"硬性禁止"末条
- **自包含**：HTML 内联 `<style>` / `<script>`，**不要**引外链 CDN（用户下载下来可能离线打开）
- **UTF-8 + `<meta charset="UTF-8">`**：浏览器才能正确显示中文
- **不要 sleep / setInterval > 100s 的死循环**：纯静态文件该是"打开即用"，不该让浏览器烧 CPU
- **文件名用纯英文 / 中文均可**，沙箱文件系统是 UTF-8；但 mimeType 一定按"文件产物"表查表，不要凭感觉编一个

---

## 图片产物（与 `python-matplotlib` 协同）

只要脚本会产出 PNG/JPG/SVG/WEBP 图片，统一走 **ExportArtifact 出 URL**，**不要**再用 base64 内联 data URI。

### ExportArtifact URL

脚本把图写到沙箱相对路径（例 `output/chart.png`），跑完后再调一次 `ExportArtifact`：

```json
{ "filePath": "output/chart.png", "mimeType": "image/png" }
```

返回 `url` 字段原值，原样填进 `![chart](http://.../download/<id>/chart.png)`。多张图就**多次调用** `ExportArtifact`，**一张图一次**，不要打包 zip（除非用户要求）。

### CJK 字体（标题/标签有中文时必备）

matplotlib 默认字体不含中文。任何含中文的图都要嵌这段：

```python
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.font_manager as fm

_AVAILABLE = {f.name for f in fm.fontManager.ttflist}
for _c in ["Noto Sans CJK JP", "Noto Sans CJK SC", "WenQuanYi Zen Hei",
           "Source Han Sans CN", "PingFang SC", "Microsoft YaHei", "SimHei"]:
    if _c in _AVAILABLE:
        plt.rcParams["font.sans-serif"] = [_c, "DejaVu Sans"]
        break
plt.rcParams["axes.unicode_minus"] = False
```

详见 `Ref/skills/python-matplotlib/SKILL.md` 的"中文标题 / CJK 字体"小节，规则一致，不再重复。

---

## 文件产物（非图片）

csv / xlsx / json / zip / pdf / txt 等都按 ExportArtifact 出 URL：

```json
{ "filePath": "output/result.csv", "mimeType": "text/csv" }
```

常见 mimeType 速查：

| 扩展名 | mimeType |
|---|---|
| .csv | `text/csv` |
| .json | `application/json` |
| .xlsx | `application/vnd.openxmlformats-officedocument.spreadsheetml.sheet` |
| .xls | `application/vnd.ms-excel` |
| .zip | `application/zip` |
| .pdf | `application/pdf` |
| .txt / .log | `text/plain` |
| .html | `text/html` |
| .md | `text/markdown` |

把返回的 `url` 原样填进 `[文件名](url)`，**不要** url-encode、**不要**改路径段。

文件 > 10 MB 之前先在 stdout 提示用户"产物较大（X MB），下载链接如下"。

---

## 常见任务模板

完整 5 个 Python 模板（CSV / 算法 / 重命名 / 抓取 / JSON）见 [`reference.md`](reference.md)，按需 Read。下面只放静态路径的入门模板 —— 这是和 Python 路径**判断错就出问题**的差异点，必须放在主文件里反复看见。

### 静态前端产物（HTML / SVG / Markdown 等"代码即交付物"）

判定信号：用户要的就是一份能直接打开的文件（"做个小游戏"/"给我一个登录页 HTML"/"画一个 SVG logo"），**不需要任何计算**。

固定姿势：

1. 用 `Write` 把目标文件原生落到 `output/<name>.<ext>`
2. `ExportArtifact` 出下载链接（mimeType 查表）
3. 块 A 用产物语言标签

**反面教材**（这是用户实际遇到过的失败模式，千万不要）：

```python
# main.py  —— ❌ 错示范
import os
os.makedirs("output", exist_ok=True)
html_content = r"""<!DOCTYPE html>... 几百行 ..."""
open("output/snake.html", "w", encoding="utf-8").write(html_content)
print("done")
```

`r"""..."""` 边界经常和 HTML 内的 `"""` / 反斜杠组合打架；同一份内容在 token 里出现两次（字面量 + 实际文件），长产物末尾被截断的概率显著上升。

**正面写法**（贪吃蛇为例）：

1. `Write filePath="output/snake.html" content="<!DOCTYPE html>...完整 HTML..."`
2. `ExportArtifact filePath="output/snake.html" mimeType="text/html"` → 拿到 `url`
3. 最终回复：

````
```html
<!DOCTYPE html>
<html>... 完整 HTML ...</html>
```

[snake.html](http://.../download/<id>/snake.html) — 单文件，浏览器打开即玩
````

---

## 异常处理 & 常见坑

| 现象 | 处理 |
|---|---|
| `ModuleNotFoundError` | 沙箱网络较慢，需要装依赖时**用国内镜像加速**，例：`pip3 install -i https://pypi.tuna.tsinghua.edu.cn/simple <pkg>`（或阿里 `https://mirrors.aliyun.com/pypi/simple`）。装完仍失败或缺系统库 → 告诉用户缺什么、问要不要换实现思路 |
| `UnicodeDecodeError` 读文件 | 显式带 `encoding="utf-8"`；中文 csv 常见 `gbk` / `utf-8-sig`，二选一试 |
| `PermissionError` 写文件 | 检查路径，沙箱里只能写当前工作目录及子目录；**不要**写 `/tmp` 之外的绝对路径 |
| `RuntimeError: main thread is not in main loop`（matplotlib） | 漏了 `matplotlib.use("Agg")`，要放在 `import pyplot` 之前 |
| 中文显示为 `□□□` | 没配 CJK 字体，按上面"CJK 字体"片段加 `font.sans-serif` |
| ExportArtifact 报 `Artifact not found in sandbox` | 文件没生成；先 `Bash` 跑 `ls output/` 确认 |
| ExportArtifact 报 `exceeds max size` | 产物太大；降数据量 / 降图分辨率重跑，或者拆成多个文件 |
| 脚本在沙箱跑超过 30 秒还没结束 | 立刻 `Ctrl-C`；查死循环或者数据量；告诉用户"任务量过大，需要换思路" |

---

## 速查表

| 任务 | 路径 | 关键动作 | 块 A 标签 | 块 B |
|---|---|---|---|---|
| 只算数 / 只 print | Python | `print(result)` | `python` | 文本块 |
| 单张图 | Python | `fig.savefig("output/x.png")` + `ExportArtifact` | `python` | `![chart](url)` |
| 多张图 | Python | 多次 `savefig` + 多次 `ExportArtifact` | `python` | 多个 `![chart](url)` |
| 出 csv / xlsx / json | Python | `to_csv` / `open(...).write(...)` + `ExportArtifact` | `python` | `[文件](url)` |
| 出 zip | Python | `shutil.make_archive(...)` + `ExportArtifact` | `python` | `[bundle.zip](url)` |
| **HTML / SVG / Markdown 静态产物** | **静态** | **`Write output/x.html`** + `ExportArtifact` | **`html` / `svg` / `markdown`** | `[文件](url)` |
| 失败 2 次 | 两路径通用 | 停手 | 不出代码块 | `执行失败（已重试 2 次）：...` |

---

## 工作流总结

1. **Step 0 分流**：先判断"需要算才有结果" vs "产物就是静态文件本身"，挑路径 —— 这一步**不能省**。
2. **拆解任务**：判断要不要绘图、要不要出文件、stdout 该 print 什么。
3. **落盘**：`Write` 工具写 `main.py`（Python 路径）或 `output/<name>.<ext>`（静态路径），按对应"硬性约定"。
4. **（仅 Python 路径）执行**：`Bash` 跑 `python main.py`；失败 ≤ 2 次重试。
5. **导出产物**：所有文件产物（图片 / csv / html / zip / …）统一用 `ExportArtifact` 拿 URL。
6. **交付**：按"最终回复格式"组织 —— 代码块在前（标签按路径选），结果块按"文本 → 图 → 文件"顺序在后；除这些块外**不输出任何额外文字**。
